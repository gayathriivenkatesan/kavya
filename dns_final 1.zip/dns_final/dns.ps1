﻿############################################################################
#
# DNS CREATION/ MODIFICATION/ DELETION
#
############################################################################
$sleepvar= "1" #set the sleep time here
Start-Transcript -Path $path\dnsreport$date.log
$path = split-path -parent -Path ($MyInvocation.MyCommand.Path)
$date = Get-Date -Format "dd_MM_yyyy_hh_mm"
if(!(Test-Path -Path "$path\inputdns\")){
    New-Item "$path\inputdns\" -ItemType Directory
}
#$csv = import-csv -Path "C:\gaya3\F5_task\dns\dns\crud_dns\DNS-WAF\WAF_inputsheet.csv" 
$csv = import-csv -Path $path\WAF_inputsheet.csv 
try{
    $a= python "$path\Thycotic.py"
    $scriptDir = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
    $Username=(($a.split(","))[0].replace("[","")).replace("'","")
    $Username1=("jdadelivers\"+$Username).ToString()
    $Password=((($a.split(","))[1].replace("]","")).replace(" ","")).replace("'","").ToString()
    $password1=ConvertTo-SecureString $Password -AsPlainText -Force
    $Credential = New-Object System.Management.Automation.PSCredential ("$Username1", $password1)
    }
 catch{
    write-host "Unable to fetch password from thycotic $a"
    write-host "Failed $_"
    exit
    }
$output1=@()
foreach($i in $csv)
{
 
 $fip1=$i.'iDNS'
 $fip2=$i.'eDNS'
 $fqdn = $i.FQDN
 $hostname= $fqdn.split('.')[0]
 $zonename = $fqdn.split('.')[1]+'.'+$fqdn.split('.')[2]  #zonename
 $action = $i.Type
 $dnstype = $i.'DNS Type'
 $ttlidns= $i.'TTL_iDNS'
 $ttledns=$i.'TTL_eDNS'
 $idnstomodify=$i.'iDNS_to_modify'
 $ednstomodify=$i.'eDNS_to_modify'
 
 try
 {
 $server1="scdc01.jdadelivers.com","msdns03.jdadelivers.com"
 $f=@()
    foreach($server in $server1){
    #$fr=$fip1+"/"+$fip2
    if($server.ToString() -eq "scdc01.jdadelivers.com")
        {
        $fip=$fip1
        $idnsm=$idnstomodify      
        if($ttlidns -eq $null){
        $ttli='01:00:00'
        }
        else{
        $ttli=$ttlidns
        }     
        }
        else{

            $fip=$fip2
            $idnsm=$ednstomodify
            if($ttledns -eq $null){
            $ttli='00:05:00'
            }
            else{
            $ttli=$ttledns
            }
        }
        $fip
        if($fip -ne ""){
        $c=Invoke-Command -ComputerName $server -Credential $Credential -FilePath  "$path\curd_check2.ps1" -ArgumentList $fip,$fqdn,$hostname,$zonename,$action,$dnstype,$server,$ttli,$idnsm,$sleepvar
        $dw=$server+"-"+$c 
        $f+=$dw
        }
        else{
        $dw=$server+"-"+"No Record in Input"
        $f+=$dw
        }
    }
    #$f
    $d=New-Object -TypeName psobject   
    Add-Member -InputObject $d  -MemberType NoteProperty -Name 'Action' -Value $i.Type;
    Add-Member -InputObject $d  -MemberType NoteProperty -Name 'DNSType' -Value $i.'DNS Type';  
    Add-Member -InputObject $d  -MemberType NoteProperty -Name 'FQDN' -Value $i.FQDN;
    Add-Member -InputObject $d  -MemberType NoteProperty -Name 'Current_iDNS' -Value $fip1; 
    Add-Member -InputObject $d  -MemberType NoteProperty -Name 'Current_eDNS' -Value $fip2;
    Add-Member -InputObject $d  -MemberType NoteProperty -Name 'iDNS_Modify' -Value $idnstomodify;
    Add-Member -InputObject $d  -MemberType NoteProperty -Name 'eDNS_Modify' -Value $ednstomodify;
    Add-Member -InputObject $d  -MemberType NoteProperty -Name 'STATUS-iDNS' -Value $f[0];  
    Add-Member -InputObject $d  -MemberType NoteProperty -Name 'STATUS-eDNS' -Value $f[1];
    $output1+= $d
   
  }
  catch{
    write-host $_
    write-host "Unable to connect"
    }   
}
$output1
$output1|export-csv -Path $path\dnsreport$date.csv -NoTypeInformation
stop-transcript


