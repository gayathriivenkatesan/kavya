import requests
import base64
import urllib
import json
import requests
#https://www.base64encoder.io/

site = 'https://cloudpmp.jdadelivers.com' #ex: http://domain.com/SecretServer
authApi = '/oauth2/token'
api = site + '/api/v1'
username = '_auto_Thycotic_'
base64_string = "S3lOamVVRVFPNDczMjdAeg==" #encrypted Password S3lOamVVRVFPNDczMjdAeg==
base64_bytes = base64_string.encode("ascii")
password = base64.b64decode(base64_bytes)

#Authenticate to Secret Server
def getAuthToken(username, password):
    try:
        creds = {}
        creds['username'] = username
        creds['password'] = password.decode('ascii')
        creds['grant_type'] = 'password'
        creds['domain'] = 'jdadelivers'
        uri = site + authApi
        headers = {'Accept':'application/json', 'content-type':'application/x-www-form-urlencoded'}
        resp = requests.post(uri, data=creds, headers=headers)
        data=resp.json()
        #print(resp.status_code)
        #sub = json.loads(resp.text)
        if resp.status_code not in (200, 304):
            raise Exception("Problems getting a token from Secret Server for %s. %s %s" % (username, resp.status_code, resp))
            
        return resp.json()["access_token"]
    except:
        print("Problems getting a token from Secret Server")

def GetSecret(token, secretId):
    try:
        headers = {'Authorization':'Bearer ' + token, 'content-type':'application/json'}
        resp = requests.get(api + '/secrets/' + str(secretId), headers=headers)
        #print(resp.status_code)
        

        if resp.status_code not in (200, 304):
            #print(resp.content)
            #print("Secret Id {}".format(secretId))
            raise Exception("Error retrieving Secret. %s %s" % (resp.status_code, resp))
           
        return resp.json()
    except:
         print("Error retrieving Secret")

         
#Retrieves the secret item by its "slug" value
def GetItemBySlug(secretItems, slug):
    for x in secret['items']:
        if x['slug'] == slug:
            return x
    raise Exception('Item not found for slug: %s' % slug)

def getPasswordord(secreteid):
    pwd=''
    username1=''
    token = getAuthToken(username, password)
    #print("Authentication successful.{}".format(token))
    secret = GetSecret(token, secreteid)
    #print(secret)
    #print("Secret Name: " + secret['name'])
    #print("Secret ID: " + str(secret['id']))
    #print("Active: " + str(secret['active']))
    for i in secret['items']:
        if i['fieldName'] == 'Password':
            pwd=(i['itemValue'])
        if i['fieldName']== 'Username':
            username1=(i['itemValue'])
    return username1,pwd
        

a=getPasswordord(119629)
print(list(a))

