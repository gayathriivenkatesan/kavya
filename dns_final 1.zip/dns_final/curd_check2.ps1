﻿[CmdletBinding()]
    param (
        [Parameter()]
        [String]
        $fip,
        [Parameter()]
        [String]
        $fqdn,
        [Parameter()]
        [String]
        $hostname,
        [Parameter()]
        [String]
        $zonename,
        [Parameter()]
        [String]
        $action,
        [Parameter()]
        [String]
        $dnstype,
        [Parameter()]
        [String]
        $server,
        [Parameter()]
        [String]
        $ttl,
        [Parameter()]
        [String]
        $idnsm,
        [Parameter()]
        [String]
        $sleepvar
        
    )

$fip1=$fip
$fip2=$idnsm
$rec=@()


$fipz=$fip+"."
$fipz1=$fip2+"."

#CREATION
 if($action -eq "creation")
 {
    if($dnstype -eq 'A')   
    {  
        $data=@()
        $datae=@()
        write-host("Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType A |?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip} -ErrorAction SilentlyContinue")
        $data=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType "A" |?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip} -ErrorAction SilentlyContinue
        write-host $data.hostname
        $datae=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType "A" -ErrorAction SilentlyContinue
        if($null -eq $data.hostname){
             $count=$datae.recorddata.ipv4address.count
             #$count
             $al=$datae.recorddata.ipv4address.ipaddresstostring
            if($count -eq 0){           
                write-host("Add-DnsServerResourceRecord -ZoneName $zonename -A -Name $hostname -ComputerName $server  -IPv4Address  $fip -TimeToLive $ttl")
                Add-DnsServerResourceRecord -ZoneName $zonename -A -Name $hostname -ComputerName $server  -IPv4Address  $fip -TimeToLive $ttl  
                #if($ttl -eq $null){
                #    if($server -eq "scdc01.jdadelivers.com"){
                #    Add-DnsServerResourceRecord -ZoneName $zonename -A -Name $hostname -ComputerName $server  -IPv4Address  $fip -TimeToLive 01:00:00  
                #    }
                #    else{
                #    Add-DnsServerResourceRecord -ZoneName $zonename -A -Name $hostname -ComputerName $server  -IPv4Address  $fip -TimeToLive 00:05:00  
                #    }
                #}
                #else{
                #Add-DnsServerResourceRecord -ZoneName $zonename -A -Name $hostname -ComputerName $server  -IPv4Address  $fip -TimeToLive $ttl  # -AgeRecord -CreatePtr #check for hostname
                #}
                Start-Sleep $sleepvar;
                $data1=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType "A" |?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip} -ErrorAction SilentlyContinue 
                    if($null -ne $data1.hostname){ 
	                $rec="Created 'A' record Successfully "
                    }
                    else
                    {
	                $rec="Unable to Create 'A' record"
                    #write-host("Unable to add record ")
                    }
            }
            else{
            $rec="Alert! Data has more ip reference - $al"
            #write-host("Alert! Data has more ip reference - $a1")
            }

            }
            else{
	            $rec="A Record already Exist"
                #write-host("Record already Exist")
                
            }

 
    }


    elseif($dnstype -eq 'CName')
    {
            $datae=@()
            $fipz1=$fip+"."
            write-host("Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CNAME |?{$_.RecordData.Hostnamealias -eq $fipz1} -ErrorAction SilentlyContinue")
            $datae=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CNAME |?{$_.RecordData.Hostnamealias -eq $fipz1} -ErrorAction SilentlyContinue
            $datae.hostname
            $datae4=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CNAME
            if($null -eq $datae.hostname)
            {
                $count=$datae4.recorddata.hostnamealias.count
                #$count
                $al=$datae4.recorddata.hostnamealias
                if($count -eq 0){ 
                   
                    write-host("Add-DnsServerResourceRecordCName -Name $hostname -HostNameAlias $fip -ZoneName $zonename -ComputerName $server -TimeToLive $ttl")
                    Add-DnsServerResourceRecordCName -Name $hostname -HostNameAlias $fip -ZoneName $zonename -ComputerName $server  -TimeToLive $ttl
                    Start-Sleep $sleepvar;
                    $data5=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CName|?{$_.RecordData.Hostnamealias -eq $fipz1} -ErrorAction SilentlyContinue
                    if($null -ne $data5.hostname){
	                $rec="Created 'Cname' record Successfully"
                    write-host("Created 'Cname' record Successfully")
                    }
                    else
                    {
	                $rec="Unable to Create Cname record "
                    $rec= $_
                    write-host("unable to add  CNAME record ")
                    write-host $_
                    }
                }
                else{
                $rec="Alert! Data has more ip reference - $al"
                write-host("Alert! Data has more ip reference - $a1")
                }

            }
            else{
	        $rec="'Cname' Record already Exist"
            write-host("Record already Exist")
            }

    }
    else {
	$rec="Wrong Record type /entry is neither A record or CName"
    write-host "Wrong Record type /entry is neither A record or CName"
    }
  $rec
  }
 


 

#DELETION
elseif($action -eq "deletion")
{
   if($dnstype -eq 'A')
   { 
    $data=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType "A"| ?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip} -ErrorAction SilentlyContinue
    #$data.hostname
    if($null -ne $data.hostname)
         {
         Write-Host "Deleting A Record from DNS "$data.HostName"" -ForegroundColor Green 
         Remove-DnsServerResourceRecord -ZoneName $zonename -ComputerName $server -RRType "A" -Name $hostname -RecordData $fip -Force -Confirm:$false #-ErrorAction SilentlyContinue  
         Start-Sleep $sleepvar;
         $data1=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType "A"  |?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip} -ErrorAction SilentlyContinue
         if($data1.hostname -ne $null)
         {
         $rec="Unable to delete 'A' record"
         write-host("unable to delete record")
         write-host $_ 
         }
         else{
         $rec="Deleted 'A' record Successfully"        
         }

      }
    else{
         $rec="Invalid Data.Data Not found"
         Write-Host "Invalid Data.Data Not found"
      }  
     }

      
   elseif($dnstype -eq 'CName')
   {
        #$datae=@() 
        write-host("Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CName |?{$_.RecordData.Hostnamealias -eq $fipz} -ErrorAction SilentlyContinue")   
        $datae=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CName |?{$_.RecordData.Hostnamealias -eq $fipz} -ErrorAction SilentlyContinue
        $count=$datae.recorddata.count
        #$count
        $al=$datae.recorddata.Hostnamealias
        #$al
        if($null -ne $datae.hostname)
         {
            Write-Host "Deleting CName Record from DNS "$da.HostName"" -ForegroundColor Green
            Remove-DnsServerResourceRecord -ZoneName $zonename -ComputerName $Server -RRType $dnstype -Name $hostname -RecordData $fipz -Force -Confirm:$false
            Start-Sleep 5;
            $data5=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CName |?{$_.RecordData.Hostnamealias -eq $fipz} -ErrorAction SilentlyContinue
            if($null -ne $data5.hostname) 
            {
            $rec="Unable to delete 'cname' record"
            write-host("unable to delete record")
            write-host $_ 
            }
            else{
            $rec="Deleted 'cname' record Successfully"
                        
        
            }
         }
        else{
          $rec="Invalid Data Data Not found"
          Write-Host "Invalid Data Data Not found"
        }

      
   }
   else {
    $rec="The entry is neither A record or CName"
       write-host "The entry is neither A record or CName"
   }
 $rec

 }




#modification

 elseif($action -eq "modification") 
 {

  if($dnstype -eq 'A')
    {     
          $old1=@()
          $new=@()
          $old1 =Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType "A" |?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip1} -ErrorAction SilentlyContinue 
          $old2 =Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType "A"       
          if($null -ne $old1.hostname) 
          {
                $count = $old2.RecordData.IPv4Address.Count
                $a1=$old2.RecordData.IPv4Address.ipaddresstostring
                if($count -eq 1){
                $new = Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType A |?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip1} -ErrorAction SilentlyContinue
                $new.recorddata.ipv4address=[System.Net.IPAddress]::parse($fip2)
                $new.TimeToLive = [System.TimeSpan]$ttl
                Set-DnsServerResourceRecord -NewInputObject $new -OldInputObject $old1 -ZoneName $zonename -ComputerName $server -PassThru           
                Start-Sleep $sleepvar;
                $new1 = Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType A |?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip2} -ErrorAction SilentlyContinue
                    #if($null -ne $new1 -and ($new1.Recorddata.ipv4address.ipaddresstostring -eq $fip2)){
                    #if($new1.Recorddata.ipv4address.ipaddresstostring -eq $fip2){
                    if($null -ne $new1.hostname){
                    $rec="$fip2 - Modified A record successfully"
                    write-host("$fip2 - Modified A record successfully")
                    }
                    else{
                    $rec="Unable to Modify A record"
                    write-host("Unable to Modify A record")
                    }
                }
                
                else{   
                $rec= "Alert many ip entries found - $a1"        
                Write-host("Alert many ip entries found - $a1")
                }
          }
          else{
          $rec="Record not Exist"
          Write-Host("Record not Exist")
          }             
     $rec     
     }   
   elseif($dnstype -eq 'CName')
   {
          $old2=@()
          $new2=@()
          $fipzq=$fip+"."
          #$hostname
          $old2 =Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CNAME |?{$_.RecordData.HostNameAlias -eq $fipzq} -ErrorAction SilentlyContinue        
          write-host("Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CNAME |?{$_.RecordData.HostNameAlias -eq $fipz} -ErrorAction SilentlyContinue")
          $old4 =Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CNAME
          if($null -ne $old2.hostname) 
            { 
                $count = $old4.RecordData.HostNameAlias.Count
                $a2=$old4.RecordData.HostNameAlias
                if($count -eq 1){ 
                #$old2.RecordData.HostNameAlias
                $new2 = Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CNAME |?{$_.RecordData.HostNameAlias -eq $fipz} -ErrorAction SilentlyContinue
                $new2.RecordData.HostNameAlias=$fip2
                $new2.TimeToLive = [System.TimeSpan]$ttl
                #$new2.RecordData.HostNameAlias
                Set-DnsServerResourceRecord -NewInputObject $new2 -OldInputObject $old2 -ZoneName $zonename -ComputerName $server -PassThru           
                Start-Sleep $sleepvar;
                write-host("Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CNAME |?{$_.RecordData.HostNameAlias -eq $fipz1} -ErrorAction SilentlyContinue")
                $new3 = Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CNAME |?{$_.RecordData.HostNameAlias -eq $fipz1} -ErrorAction SilentlyContinue
                    #if($null -ne $new3.hostname -and ($new3.RecordData.HostNameAlias -eq $fip2)){
                    #$new3.RecordData.HostNameAlias
                    #$fip2
                    if($null -ne $new3.hostname){
                    $rec="Modified CNAME record successfully to $fipz1"
                    write-host("Modified CNAME record successfully to $fipz1")
                    }
                    else{
                    $rec="Unable to Modify CNAME record"
                    write-host("Unable to Modify CNAME record")
                    }
                }
                else{   
                    $rec= "Alert many ip entries found - $a2"        
                    Write-host("Alert many ip entries found - $a2")
                }
          }
          else{
          $rec="Record not Exist"
          Write-Host("Record not Exist")
          }             
     $rec     
    
     }

  elseif($dnstype -eq 'AtoCName')
    {       $rec1=@() 
            $datat=@()
            $datae=@()
            $datae1=@()
            $data=@()
            $data5=@()
            $data1=@()

            $datat=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType "A"|?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip1} -ErrorAction SilentlyContinue
            $data=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType "A"
            #write-host "Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType 'A'|?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip2} -ErrorAction SilentlyContinue"
            if($null -ne $datat.hostname){
                $count=$data.recorddata.ipv4address.count
                $al=$data.recorddata.recorddata.ipv4address
                if($count -eq 1){
                    Write-Host "Deleting A Record from DNS "$datat.HostName"" -ForegroundColor Green 
                    Remove-DnsServerResourceRecord -ZoneName $zonename -ComputerName $server -RRType "A" -Name $hostname -RecordData $fip1 -Force -Confirm:$false #-ErrorAction SilentlyContinue  
                    Start-Sleep $sleepvar;
                    $data1=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType "A"  |?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip1} -ErrorAction SilentlyContinue
                    if($data1.hostname -ne $null){
                        $rec="Unable to delete 'A' record"
                        write-host("unable to delete record")
                        write-host $_ 
                    }
                    else{
                        $rec="Deleted 'A' record Successfully"
                        #Adding CName record here 
                        $datae=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CNAME |?{$_.RecordData.Hostnamealias -eq $fipz1} -ErrorAction SilentlyContinue                
                        if($null -eq $datae.hostname)
                        {
                            write-host(" Add-DnsServerResourceRecordCName -Name $hostname -HostNameAlias $fip2 -ZoneName $zonename -ComputerName $server  -TimeToLive $ttl")
                            #Add-DnsServerResourceRecord -CName -Name $hostname -ComputerName $server -ZoneName $zonename -HostNameAlias $fip2  -AllowUpdateAny -TimeToLive 01:00:00 -ErrorAction SilentlyContinue
                            Add-DnsServerResourceRecordCName -Name $hostname -HostNameAlias $fip2 -ZoneName $zonename -ComputerName $server  -TimeToLive $ttl
                            Start-Sleep $sleepvar;
                            $data5=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CName|?{$_.RecordData.Hostnamealias -eq $fipz1} -ErrorAction SilentlyContinue
                            if($null -ne $data5.hostname){
	                            $rec="Created Cname record Successfully"
                                write-host("Created Cname record Successfully")
                            }
                            else{
                                $rec="Unable to create CName record "
                                write-host("Unable to create CName record")
                            }
                        }
                        else{       
                            $rec="Cname Record already Exist"
                            write-host("Record already Exist")
                        }


                    }
                }
                else{
                $rec="Alert! Data has more ip reference - $al"
                write-host("Alert! Data has more ip reference - $a1")
                }
             }    
             else{
                 $rec="A Record Not Exist"
                write-host("A Record Not Exist")
            }
  $rec
  }   
            
  elseif($dnstype -eq 'CNametoA')
  {  
      $datae=@()
      $data=@()
      $dataeq=@()
      $data=@()
      $data5=@()
      $data1=@()
      $fipz=$fip+"."
      $fipz1=$fip2+"."

      #$datat=@()
      write-host("Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CName |?{$_.RecordData.Hostnamealias -eq $fipz} -ErrorAction SilentlyContinue")
      $datae=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CName |?{$_.RecordData.Hostnamealias -eq $fipz} -ErrorAction SilentlyContinue
      $dataeq=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CName
      if($null -ne $datae.hostname){
            $count=$dataeq.recorddata.hostnamealias.count
            $al=$dataeq.recorddata.hostnamealias
            if($count -eq 1){
                Write-Host "Deleting CName Record from DNS "$datae.HostName"" -ForegroundColor Green
                Remove-DnsServerResourceRecord -ZoneName $zonename -ComputerName $Server -RRType CName -Name $hostname -RecordData $fipz -Force -Confirm:$false
                Start-Sleep $sleepvar;
                $data5=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType CName |?{$_.RecordData.Hostnamealias -eq $fipz} -ErrorAction SilentlyContinue
                if($null -ne $data5.hostname) 
                {
                    $rec="Unable to delete cname record"
                    write-host("Unable to delete cname record")
                    #write-host $_ 
                }
                else{
                    $rec="Deleted cname record Successfully"
                    write-host("Deleted cname record")
                    $data=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType "A" |?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip2} -ErrorAction SilentlyContinue
                    if($null -eq $data.hostname){
                          Add-DnsServerResourceRecord -ZoneName $zonename -A -Name $hostname -ComputerName $server  -IPv4Address  $fip2 -TimeToLive 01:00:00 -ErrorAction SilentlyContinue # -AgeRecord -CreatePtr #check for hostname
                          Start-Sleep $sleepvar;
                          $data1=Get-DnsServerResourceRecord -ZoneName $zonename  -Name $hostname -ComputerName $server -RRType "A" |?{$_.RecordData.ipv4address.ipaddresstostring -eq $fip2} -ErrorAction SilentlyContinue 
                          if($null -ne $data1.hostname){ 
                             $rec="Created 'A' record Successfully"
                             write-host("Created 'A' record Successfully")  
                          }
                          else{
                            $rec="Unable to create A Record"
                            Write-Host "Unable to create A Record"
                          }


                    }
                    else
                       {
                           $rec="A Record already Exists"
                           write-host("A Record already Exists ")
                       }

                }
            }
            else{
              $rec="Alert! Data has more ip reference - $al"
              write-host("Alert! Data has more ip reference - $a1")  
            }
     }
     else{
       $rec="Invalid Data Data Not found"
       Write-Host "Invalid Data Data Not found"
     }
  $rec
  }


 }       
       

else{
  write-host("Invalid Type")
    $rec="Invalid Type"
}












