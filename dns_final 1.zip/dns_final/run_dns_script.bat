@echo off
Powershell.exe .\dns.ps1
pause